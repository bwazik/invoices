        <!--=================================
 header start-->
 <nav class="admin-header navbar navbar-default col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
    <!-- logo -->
    <div class="text-left navbar-brand-wrapper">
        <a class="navbar-brand brand-logo" href="<?php echo e(route('dashboard')); ?>"><img
                src="<?php echo e(URL::asset('assets/images/logo-dark.png')); ?>" alt=""></a>
    </div>
    <!-- Top bar left -->
    <ul class="nav navbar-nav mr-auto">
        <li class="nav-item">
            <a id="button-toggle" class="button-toggle-nav inline-block ml-20 pull-left"
                href="javascript:void(0);"><i class="zmdi zmdi-menu ti-align-right"></i></a>
        </li>
    </ul>
    <!-- top bar right -->
    <ul class="nav navbar-nav ml-auto">
        <div class="btn-group mb-1">
            <button type="button" style="background-color: transparent; border: transparent;" class="btn btn-light btn-sm dropdown-toggle" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <?php if(App::getLocale() == 'ar'): ?>
                    <?php echo e(LaravelLocalization::getCurrentLocaleName()); ?>

                    <img src="<?php echo e(URL::asset('assets/images/flags/AR.png')); ?>" alt="">
                <?php else: ?>
                    <?php echo e(LaravelLocalization::getCurrentLocaleName()); ?>

                    <img src="<?php echo e(URL::asset('assets/images/flags/EN.png')); ?>" alt="">
                <?php endif; ?>
            </button>
            <div class="dropdown-menu">
                <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="dropdown-item" rel="alternate"
                        href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>">
                        <?php echo e($properties['native']); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <li class="nav-item dropdown mr-30">
            <a class="nav-link nav-pill user-avatar" data-toggle="dropdown" href="#" role="button"
                aria-haspopup="true" aria-expanded="false">
                <img src="<?php echo e(URL::asset('assets/images/profile-avatar.png')); ?>" alt="avatar">
            </a>
            <div class="dropdown-menu dropdown-menu-right">
                <div class="dropdown-header">
                    <div class="media">
                        <div class="media-body">
                            <h5 class="mt-0 mb-0"><?php echo e(Auth::user()->name); ?></h5>
                            <span><?php echo e(Auth::user()->email); ?></span>
                        </div>
                    </div>
                </div>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="<?php echo e(route('roles')); ?>"><i class="text-info ti-settings"></i><?php echo e(trans('roles/roles.pageTitle1')); ?></a>
                <a class="dropdown-item" href="#"
                    onclick="event.preventDefault();document.getElementById('logout-form').submit();"><i
                        class="text-danger ti-unlock"></i><?php echo e(trans('layouts/sidebar.logout')); ?></a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                    style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </li>
    </ul>
</nav>

<!--=================================
header End-->
<?php /**PATH C:\xampp\htdocs\invoices\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>