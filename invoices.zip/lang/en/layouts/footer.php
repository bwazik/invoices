<?php

return [

    'all_rights_reserved' => 'All Rights Reserved',

    'terms_conditions' => 'Terms & Conditions',
    'privacy_policy' => 'Privacy Policy',
];