<?php

return [
    # Header
    'title' => 'Print Invoice - Invoices Managment Program',
    'pageTitle1' => 'Print Invoice',
    'subTitle' => 'List',

    'email'=> 'Email',
    'phone'=> 'Phone',
    'information'=> 'Invoice Information',
    'to'=> 'Invoice to',
    'total' => 'Total Amount',
    'print'=> 'Print',
];
