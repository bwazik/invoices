<?php

return [
    # Header
    'title' => 'Invoice Archive - Invoices Managment Program',
    'pageTitle1' => 'Invoice Archive',
    'subTitle' => 'Invoices',
];
