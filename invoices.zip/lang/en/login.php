<?php

return [

    'title' => 'Invoices Managment Program',
    'system' => 'Invoices System',
    'p' => 'Invoices, Depts, Loans managment program made by (Abdullah Mohamed).',

    'login' => 'Login',
    'email' => 'Email',
    'password' => 'Password',
    'submit' => 'Login',

];
