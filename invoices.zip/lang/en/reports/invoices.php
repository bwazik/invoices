<?php

return [
    # Header
    'title' => 'Invoices Reports - Invoices Managment Program',
    'pageTitle1' => 'Invoices Reports',
    'subTitle' => 'Reports',

    'numberSearch' => 'Search by number',
    'dateSearch' => 'Search by date',
    'all' => 'All Invoices',
    'start_date' => 'From date',
    'end_date' => 'to date',
];
