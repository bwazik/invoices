<?php

return [
    # Header
    'title' => 'Customers Reports - Invoices Managment Program',
    'pageTitle1' => 'Customers Reports',
    'subTitle' => 'Reports',
    
    'start_date' => 'From date',
    'end_date' => 'to date',
];
