<?php

return [

    'row1_title' => 'Half Year Invoices Statistics ( Numbers )',
    'row2_title' => 'Invoices Status Statistics ( Percentage )',

    'row3_title' => 'Customers Info',
    'row3_table1' => 'Section',
    'row3_table2' => 'All Products',
    'row3_table3' => 'All Invoices',
    'row3_table4' => 'Total Invoices Amount',

];
