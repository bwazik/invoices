<?php

return [

    'all_rights_reserved' => 'جميع الحقوق محفوظة',

    'terms_conditions' => 'اتفاقية الاستخدام',
    'privacy_policy' => 'سياسة الخصوصية',

];