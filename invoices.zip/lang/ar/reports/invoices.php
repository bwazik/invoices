<?php

return [
    # Header
    'title' => 'تقارير الفواتير - برنامج إدارة الفواتير',
    'pageTitle1' => 'تقارير الفواتير',
    'subTitle' => 'التقارير',


    'numberSearch' => 'بحث برقم الفاتورة',
    'dateSearch' => 'بحث بحالة الفاتورة',
    'all' => 'جميع الفواتير',
    'start_date' => 'من تاريخ',
    'end_date' => 'إلي تاريخ',
];
