<?php

return [
    # Header
    'title' => 'تقارير العملاء - برنامج إدارة الفواتير',
    'pageTitle1' => 'تقارير العملاء',
    'subTitle' => 'التقارير',

    'start_date' => 'من تاريخ',
    'end_date' => 'إلي تاريخ',
];
