<?php

return [
    # Header
    'title' => 'أرشيف الفواتير - برنامج إدارة الفواتير',
    'pageTitle1' => 'أرشيف الفواتير',
    'subTitle' => 'الفواتير',
];
